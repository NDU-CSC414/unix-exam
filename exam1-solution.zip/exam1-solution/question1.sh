question='A file FILE contains 50 lines. Which lines of file FILE are displayed by the following command: $head -10 FILE| tail -2. Note: m-n means from line m to line n'
echo $question
cd working
rm -rf *
echo "--------------------------"
echo "output"
echo "--------------------------"
i=1
while [ $i -le 10 ]
do
	echo $i>>FILE
	i=$((i+1))
done
head -10 FILE |tail -2
