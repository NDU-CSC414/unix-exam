#include <stdio.h>
#include <unistd.h>

int main(int argc,char **argv){
        pid_t pid;
        int fd[2];
        pipe(fd);

        pid=fork();
        if(pid==0){
           dup2(fd[0],0);
           close(fd[0]);close(fd[1]);
           execlp("grep","grep","g[a-z ]*s",NULL);

        }
        else {
           dup2(fd[1],1);
                close(fd[0]);close(fd[1]);
           execlp("sed","sed","s/s/z/g",NULL);
        }
}
