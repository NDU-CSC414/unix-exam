question='This question refers to main.c, content of dir2, and script1.sh. Also, the file tmain.c is an exact copy of main.c and script2.sh is an exact copy of script2.sh. The file abc.txt is empty. What would be the output if we run $rm main.c;./script1.sh in directory dir2'
echo $question
echo "------------------"
echo "output"
echo "------------------"
cd working
rm -rf *
touch abc.txt
cat << EOF >main.c
#include <stdio.h>
int main(){

}
EOF

cat << "EOF" >script1.sh
count=0
r=0
for x in $(ls)
do
        if [ ${x%.c}.c = $x ]
        then
                r=$(grep -c stdio $x)
        fi
        count=$((count+r))
done
echo $count
EOF

cp main.c tmain.c
cp script1.sh script2.sh
rm main.c;./script1.sh
