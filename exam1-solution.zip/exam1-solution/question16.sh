question='This question refers to the content of file6.cpp. What is the output of $cc file6.cpp;$./a.out'
echo $question
echo "---------------"
echo "output"
echo "---------------"

cd working
rm -rf *

cat <<EOF >file6.cpp
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
int main(){
    pid_t pid;
    int x=2,status;
    x++;
    pid=fork();
    if (pid==0)
        printf("x=%d\n",x);
    else{
        x++;
        wait(&status);
    }
}
EOF
cc file6.cpp;./a.out
