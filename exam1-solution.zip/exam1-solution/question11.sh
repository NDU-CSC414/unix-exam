
cmd='$grep "t[a-z \'\'']*s"'
question="This question refers to the content of file1. What is the output of: ${cmd} file1 |wc -l"
echo $question
echo "--------------------"
echo "output"
echo "--------------------"
cd working
rm -rf *
cat <<EOF >file1
this is a test
for grep which is
short for gnu's regular
expression processor
it is not used for tables
therefore stop using it
EOF
grep "t[a-z \']*s" file1|wc -l


