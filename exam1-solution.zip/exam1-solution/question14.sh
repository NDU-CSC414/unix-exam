question='This question refers to the content of file4.cpp and file1. What is the output of $cc file4.cpp;$cat file1| ./a.out|wc -l'
echo $question
echo "----------------"
echo "output"
echo "----------------"

cd working
rm -rf *

cat <<EOF >file1
this is a test
for grep which is
short for gnu's regular
expression processor
it is not used for tables
therefore stop using it
EOF

cat <<EOF >file4.cpp
#include <stdio.h>
#include <unistd.h>

int main(int argc,char **argv){
        pid_t pid;
        int fd[2];
        pipe(fd);

        pid=fork();
        if(pid==0){
           dup2(fd[1],1);
           close(fd[0]);close(fd[1]);
           execlp("grep","grep","g[a-z ]*s",NULL);

        }
        else {
           dup2(fd[0],0);
                close(fd[0]);close(fd[1]);
           execlp("sed","sed","s/s/z/g",NULL);
        }
}
EOF
cc file4.cpp
cat file1|./a.out|wc -l
