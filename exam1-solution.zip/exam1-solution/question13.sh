question='This question refers to the content of file2.cpp. Given that the output of $ls -aF is "./ ../ file2.cpp" and that PATH contains all the directories, What is the output of sequence: $/usr/bin/cc ;file2.cpp;./a.out'
echo $question
echo "---------------"
echo "output"
echo "---------------"

cd working
rm -rf *
cat <<EOF > file2.cpp
#include <stdio.h>
#include <unistd.h>
int main(){
execl("ls","ls","-a",NULL);
printf("Done\n");
}
EOF
cc file2.cpp
./a.out
