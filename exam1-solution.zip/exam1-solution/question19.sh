question='What is the output of the sequence: $cd;$if [ $(pwd) = "$HOME" ]; then echo True; else echo False; fi.'
echo $question
echo "----------------"
echo "output"
echo "----------------"
cd
if [ $(pwd) = "$HOME" ]
then
	echo True
else
	echo False
fi
