question='Suppose that file File does NOT contain PAT and the following sequence is executed: $grep PAT FILE;$if [ "$?" -eq 0 ]; then echo One; else echo Two; fi. Then the output of the previous sequence is: One'
echo $question
echo "----------------"
echo "output"
echo "----------------"
cd working
rm -rf *

cat<<- EOF >FILE
one
two
three
EOF

grep PAT FILE
if [ $? -eq 0 ]
then
	echo True
else
	echo False
fi
