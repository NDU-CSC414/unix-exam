question='A file called script.sh contains only the following line if [ "$1" -eq 7 ]; then exit 1; else exit 0;fi. Now what is the output of the following sequence: $./script.sh 18;$echo $?'
echo $question
echo "-----------------"
echo "output"
echo "-----------------"
cd working
rm -rf *
cat <<-"EOF" >script.sh
if [ "$1" -eq 7 ]
then
   exit 1
else
   exit 0
fi
EOF
./script.sh 18
echo $?

