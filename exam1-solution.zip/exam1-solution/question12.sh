question='This question refers to the content of file1.cpp. Given that the output of $ls -aF is "./ ../ file1.cpp". What is the output of sequence: $/usr/bin/cc ;export PATH="";file1.cpp;./a.out'
echo $question
echo "---------------"
echo "output"
echo "---------------"

cd working
rm -rf *
cat <<EOF > file1.cpp
#include <stdio.h>
#include <unistd.h>
int main(){
execlp("ls","ls","-a",NULL);
printf("Done\n");
}
EOF
cc file1.cpp
export PATH=""
./a.out
